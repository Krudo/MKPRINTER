C:\>ps2txt.exe
VeryPDF PS to Text Converter v2.0
Web: http://www.verypdf.com
Web: http://www.verydoc.com
Email: support@verypdf.com
Build: May 14 2007
-------------------------------------------------------
Key features in PS to Text Converter:
   Convert postscript files to plain text files.
   Maintain original physical layout in text files.
-------------------------------------------------------
Usage: ps2txt.exe [options] [Options] <PS Files>
  -firstpage <int>   : first page to print, from 1 to max page
  -lastpage <int>    : last page to print, from 1 to max page
  -nolayout          : don't maintain original physical layout
  -nopgbreak         : don't insert page breaks between pages
  -$ <string>        : input registration key
Example:
   ps2txt.exe C:\input.ps C:\output.txt
   ps2txt.exe -nolayout C:\input.ps C:\output.txt
